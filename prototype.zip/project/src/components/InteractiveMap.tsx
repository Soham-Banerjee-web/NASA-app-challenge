import { MapPin, Waves, Mountain, AlertTriangle, Zap } from 'lucide-react';
import { useState } from 'react';

interface MapPoint {
  id: number;
  x: number;
  y: number;
  label: string;
  description: string;
  type: 'lake' | 'dam' | 'affected' | 'power' | 'town';
  icon: React.ReactNode;
}

export function InteractiveMap() {
  const [selectedPoint, setSelectedPoint] = useState<number | null>(null);
  const [hoveredPoint, setHoveredPoint] = useState<number | null>(null);

  const mapPoints: MapPoint[] = [
    {
      id: 1,
      x: 36,
      y: 13,
      label: 'South Lhonak Lake',
      description: 'Glacial lake at 5,200m elevation. Primary source of the GLOF event that occurred on October 4, 2023.',
      type: 'lake',
      icon: <Waves className="w-4 h-4" />
    },
    {
      id: 2,
      x: 38,
      y: 23,
      label: 'Chomoyummo',
      description: 'High-altitude location near the glacial lake system in North Sikkim.',
      type: 'town',
      icon: <MapPin className="w-4 h-4" />
    },
    {
      id: 3,
      x: 65,
      y: 10,
      label: 'Khangchengyao',
      description: 'Mountain region in the eastern part of North Sikkim.',
      type: 'town',
      icon: <MapPin className="w-4 h-4" />
    },
    {
      id: 4,
      x: 54,
      y: 31,
      label: 'Lachen',
      description: 'Mountain village in North Sikkim that experienced the initial impact of flood waters.',
      type: 'affected',
      icon: <AlertTriangle className="w-4 h-4" />
    },
    {
      id: 5,
      x: 20,
      y: 33,
      label: 'Kangchenjunga',
      description: 'Region near Kangchenjunga Conservation Area, affected by the flooding event.',
      type: 'town',
      icon: <MapPin className="w-4 h-4" />
    },
    {
      id: 6,
      x: 60,
      y: 42,
      label: 'Chungthang Dam',
      description: 'Major hydroelectric dam severely damaged. Teesta III Dam breached here, amplifying the flood impact.',
      type: 'dam',
      icon: <Mountain className="w-4 h-4" />
    },
    {
      id: 7,
      x: 50,
      y: 51,
      label: 'Mangan',
      description: 'District headquarters of North Sikkim. Critical infrastructure damage and significant population impact.',
      type: 'affected',
      icon: <AlertTriangle className="w-4 h-4" />
    },
    {
      id: 8,
      x: 42,
      y: 69,
      label: 'Yangang',
      description: 'Town in South Sikkim affected as flood waters continued downstream.',
      type: 'town',
      icon: <MapPin className="w-4 h-4" />
    },
    {
      id: 9,
      x: 57,
      y: 66,
      label: 'Sokey',
      description: 'Town along the Teesta River corridor affected by the flood waters flowing downstream.',
      type: 'affected',
      icon: <AlertTriangle className="w-4 h-4" />
    },
    {
      id: 10,
      x: 45,
      y: 66,
      label: '66/11 KV Power Station',
      description: 'Critical power infrastructure affected by the flood event.',
      type: 'power',
      icon: <Zap className="w-4 h-4" />
    },
    {
      id: 11,
      x: 42,
      y: 72,
      label: 'Teesta Power Station V',
      description: 'Hydroelectric power station impacted by the cascading flood waters.',
      type: 'power',
      icon: <Zap className="w-4 h-4" />
    },
    {
      id: 12,
      x: 40,
      y: 81,
      label: 'Singtam',
      description: 'Town in East Sikkim where flood waters continued to impact downstream communities.',
      type: 'affected',
      icon: <AlertTriangle className="w-4 h-4" />
    },
    {
      id: 13,
      x: 44,
      y: 92,
      label: 'Teesta Low Dam III',
      description: 'Downstream hydropower plant affected as flood waters traveled through the Teesta River system.',
      type: 'dam',
      icon: <Mountain className="w-4 h-4" />
    }
  ];

  const getPointColor = (type: string, isSelected: boolean, isHovered: boolean) => {
    if (isSelected) {
      return 'bg-cyan-400 ring-4 ring-cyan-400/40 scale-125';
    }
    if (isHovered) {
      return 'bg-yellow-400 ring-2 ring-yellow-400/40 scale-110';
    }
    switch (type) {
      case 'lake':
        return 'bg-red-600 hover:bg-red-500';
      case 'dam':
        return 'bg-orange-500 hover:bg-orange-400';
      case 'affected':
        return 'bg-red-500 hover:bg-red-400';
      case 'power':
        return 'bg-amber-500 hover:bg-amber-400';
      case 'town':
        return 'bg-emerald-500 hover:bg-emerald-400';
      default:
        return 'bg-red-500 hover:bg-red-400';
    }
  };

  return (
    <div className="bg-slate-800/50 rounded-xl p-8 border border-slate-600">
      <div className="relative w-full h-[600px] rounded-lg overflow-hidden border border-slate-600 shadow-2xl bg-gradient-to-br from-emerald-100 via-green-50 to-emerald-100">

        {/* Terrain background with topographic styling */}
        <svg className="absolute inset-0 w-full h-full" style={{ filter: 'opacity(0.15)' }}>
          <defs>
            <pattern id="topo" x="0" y="0" width="50" height="50" patternUnits="userSpaceOnUse">
              <circle cx="25" cy="25" r="20" fill="none" stroke="#10b981" strokeWidth="0.5" />
              <circle cx="25" cy="25" r="15" fill="none" stroke="#10b981" strokeWidth="0.5" />
              <circle cx="25" cy="25" r="10" fill="none" stroke="#10b981" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#topo)" />
        </svg>

        {/* Mountain ranges */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20">
          <path d="M 0 250 Q 150 150, 250 200 T 500 180 T 800 220 L 800 300 L 0 300 Z" fill="#059669" />
          <path d="M 0 200 Q 100 80, 200 120 T 400 100 T 650 140 T 800 120 L 800 250 L 0 250 Z" fill="#047857" />
          <path d="M 100 100 L 180 30 L 220 80 L 250 50 L 300 120 L 100 120 Z" fill="#065f46" opacity="0.6" />
          <path d="M 400 80 L 480 20 L 520 60 L 560 40 L 600 100 L 400 100 Z" fill="#065f46" opacity="0.6" />
        </svg>

        {/* River path - Teesta River */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <defs>
            <linearGradient id="riverGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.6" />
            </linearGradient>
            <linearGradient id="flowGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.9" />
              <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.7" />
              <stop offset="100%" stopColor="#2563eb" stopOpacity="0.5" />
            </linearGradient>
          </defs>

          {/* Main river path */}
          <path
            d="M 36% 13% Q 38% 20%, 40% 28% T 45% 45% T 42% 60% T 40% 75% T 42% 88% T 44% 95%"
            stroke="url(#riverGradient)"
            strokeWidth="8"
            fill="none"
            opacity="0.6"
          />

          {/* Flood flow connections between points */}
          {mapPoints.map((point, index) => {
            if (index < mapPoints.length - 1 &&
                (point.type === 'lake' || point.type === 'dam' || point.type === 'affected' || point.type === 'power')) {
              const nextPoint = mapPoints[index + 1];
              if (nextPoint.type === 'dam' || nextPoint.type === 'affected' || nextPoint.type === 'power') {
                return (
                  <path
                    key={`path-${point.id}`}
                    d={`M ${point.x}% ${point.y}% Q ${(point.x + nextPoint.x) / 2}% ${(point.y + nextPoint.y) / 2 - 2}% ${nextPoint.x}% ${nextPoint.y}%`}
                    stroke="url(#flowGradient)"
                    strokeWidth="3"
                    fill="none"
                    strokeDasharray="8 4"
                    className="animate-pulse"
                  />
                );
              }
            }
            return null;
          })}
        </svg>

        {/* Protected areas and parks */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute left-[5%] top-[25%] w-[25%] h-[35%] border-2 border-dashed border-green-600 rounded-lg bg-green-600/5">
            <span className="absolute top-2 left-2 text-xs font-semibold text-green-700 bg-white/80 px-2 py-1 rounded">
              Kangchenjunga National Park
            </span>
          </div>
        </div>

        {/* Geographic labels */}
        <div className="absolute top-4 right-4 bg-slate-900/90 backdrop-blur-sm px-4 py-3 rounded-lg text-white border border-slate-600">
          <h3 className="font-bold text-sm mb-1">Sikkim Region</h3>
          <p className="text-xs text-slate-300">North & East Districts</p>
          <p className="text-xs text-slate-400 mt-1">Teesta River Basin</p>
        </div>

        {/* Interactive markers */}
        {mapPoints.map((point) => (
          <div
            key={point.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10"
            style={{ left: `${point.x}%`, top: `${point.y}%` }}
            onClick={() => setSelectedPoint(selectedPoint === point.id ? null : point.id)}
            onMouseEnter={() => setHoveredPoint(point.id)}
            onMouseLeave={() => setHoveredPoint(null)}
          >
            <div className={`w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 ${getPointColor(point.type, selectedPoint === point.id, hoveredPoint === point.id)} shadow-lg border-2 border-white`}>
              <span className="text-white">{point.icon}</span>
            </div>

            {/* Hover label */}
            {hoveredPoint === point.id && selectedPoint !== point.id && (
              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-slate-900/95 text-white px-3 py-1 rounded text-xs whitespace-nowrap shadow-lg border border-slate-600">
                {point.label}
              </div>
            )}

            {/* Selected info panel */}
            {selectedPoint === point.id && (
              <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-3 w-72 bg-slate-900/95 backdrop-blur-sm border-2 border-cyan-500 rounded-lg p-4 shadow-2xl animate-fadeIn z-20">
                <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-slate-900 border-l-2 border-t-2 border-cyan-500 rotate-45"></div>
                <h4 className="text-white font-bold mb-2 text-base">{point.label}</h4>
                <p className="text-slate-300 text-sm leading-relaxed">{point.description}</p>
              </div>
            )}
          </div>
        ))}

        {/* Compass */}
        <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-full w-16 h-16 flex items-center justify-center shadow-lg border-2 border-slate-300">
          <div className="relative w-full h-full">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-xs font-bold text-slate-700">N</div>
            </div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-b-[24px] border-b-red-500"></div>
            </div>
          </div>
        </div>

        {/* Scale */}
        <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-2 rounded-lg shadow-lg border border-slate-300">
          <div className="flex items-center gap-2 text-xs text-slate-700">
            <div className="w-16 h-1 bg-slate-700"></div>
            <span className="font-semibold">50 km</span>
          </div>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-red-600 rounded-full border border-white"></div>
          <span className="text-slate-300 text-sm">Glacial Lake</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-orange-500 rounded-full border border-white"></div>
          <span className="text-slate-300 text-sm">Dam</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-amber-500 rounded-full border border-white"></div>
          <span className="text-slate-300 text-sm">Power Station</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-red-500 rounded-full border border-white"></div>
          <span className="text-slate-300 text-sm">Affected Area</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-emerald-500 rounded-full border border-white"></div>
          <span className="text-slate-300 text-sm">Town</span>
        </div>
      </div>
    </div>
  );
}
