import { StudyArea, SARImage, ImageOverlay, FloodMetrics, FloodPhase } from '../types/sar';

export const studyAreas: StudyArea[] = [
  {
    id: '1',
    name: 'Bangladesh Delta Region',
    location: 'Ganges-Brahmaputra Delta, Bangladesh',
    latitude: 23.8103,
    longitude: 90.4125,
    description: 'Low-lying delta region highly susceptible to monsoon flooding and cyclones'
  },
  {
    id: '2',
    name: 'Houston Metropolitan Area',
    location: 'Texas, USA',
    latitude: 29.7604,
    longitude: -95.3698,
    description: 'Urban area prone to hurricane-induced flooding, particularly from Gulf storms'
  },
  {
    id: '3',
    name: 'Venice Lagoon',
    location: 'Venice, Italy',
    latitude: 45.4408,
    longitude: 12.3155,
    description: 'Historic city facing regular acqua alta flooding and sea level rise'
  },
  {
    id: '4',
    name: 'Mumbai Coastal Zone',
    location: 'Maharashtra, India',
    latitude: 19.0760,
    longitude: 72.8777,
    description: 'Densely populated coastal megacity vulnerable to monsoon and storm surge flooding'
  },
  {
    id: '5',
    name: 'Brisbane River Basin',
    location: 'Queensland, Australia',
    latitude: -27.4698,
    longitude: 153.0251,
    description: 'River system with history of severe flooding events affecting urban areas'
  }
];

const sarImageUrls = {
  pre_flood: 'https://images.pexels.com/photos/87611/sun-fireball-solar-flare-sunlight-87611.jpeg',
  during_event: 'https://images.pexels.com/photos/1126668/pexels-photo-1126668.jpeg',
  post_analysis: 'https://images.pexels.com/photos/1252890/pexels-photo-1252890.jpeg'
};

export const sarImages: SARImage[] = studyAreas.flatMap((area, index) => [
  {
    id: `img-${area.id}-pre`,
    studyAreaId: area.id,
    imageUrl: sarImageUrls.pre_flood,
    phase: 'pre_flood' as FloodPhase,
    captureDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    satellite: 'Sentinel-1A',
    metadata: { polarization: 'VV+VH', resolution: '10m', orbit: 'descending' }
  },
  {
    id: `img-${area.id}-during`,
    studyAreaId: area.id,
    imageUrl: sarImageUrls.during_event,
    phase: 'during_event' as FloodPhase,
    captureDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
    satellite: 'Sentinel-1A',
    metadata: { polarization: 'VV+VH', resolution: '10m', orbit: 'descending' }
  },
  {
    id: `img-${area.id}-post`,
    studyAreaId: area.id,
    imageUrl: sarImageUrls.post_analysis,
    phase: 'post_analysis' as FloodPhase,
    captureDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    satellite: 'Sentinel-1B',
    metadata: { polarization: 'VV+VH', resolution: '10m', orbit: 'ascending' }
  }
]);

const overlayImageUrls = {
  water_extent: 'https://images.pexels.com/photos/1287145/pexels-photo-1287145.jpeg?auto=compress&cs=tinysrgb&w=1200',
  change_detection: 'https://images.pexels.com/photos/1274260/pexels-photo-1274260.jpeg?auto=compress&cs=tinysrgb&w=1200',
  infrastructure: 'https://images.pexels.com/photos/2166711/pexels-photo-2166711.jpeg?auto=compress&cs=tinysrgb&w=1200',
  population: 'https://images.pexels.com/photos/1486222/pexels-photo-1486222.jpeg?auto=compress&cs=tinysrgb&w=1200',
  terrain: 'https://images.pexels.com/photos/355288/pexels-photo-355288.jpeg?auto=compress&cs=tinysrgb&w=1200'
};

export const imageOverlays: ImageOverlay[] = sarImages.flatMap(image => {
  const baseOverlays: ImageOverlay[] = [];

  if (image.phase === 'pre_flood') {
    baseOverlays.push(
      {
        id: `overlay-${image.id}-water`,
        sarImageId: image.id,
        overlayType: 'water_extent',
        overlayData: { area_km2: 15.2 + Math.random() * 5, features: 'normal water bodies' },
        imageUrl: overlayImageUrls.water_extent,
        enabled: true
      },
      {
        id: `overlay-${image.id}-infra`,
        sarImageId: image.id,
        overlayType: 'infrastructure',
        overlayData: { roads: 45, buildings: 230, bridges: 3 },
        imageUrl: overlayImageUrls.infrastructure,
        enabled: false
      },
      {
        id: `overlay-${image.id}-pop`,
        sarImageId: image.id,
        overlayType: 'population',
        overlayData: { density: 'medium', count: 12000 },
        imageUrl: overlayImageUrls.population,
        enabled: false
      }
    );
  } else if (image.phase === 'during_event') {
    baseOverlays.push(
      {
        id: `overlay-${image.id}-water`,
        sarImageId: image.id,
        overlayType: 'water_extent',
        overlayData: { area_km2: 68.5 + Math.random() * 10, features: 'extensive flooding' },
        imageUrl: overlayImageUrls.water_extent,
        enabled: true
      },
      {
        id: `overlay-${image.id}-change`,
        sarImageId: image.id,
        overlayType: 'change_detection',
        overlayData: { increased_water: 53.3, unit: 'km2', change_percent: 350 },
        imageUrl: overlayImageUrls.change_detection,
        enabled: false
      },
      {
        id: `overlay-${image.id}-infra`,
        sarImageId: image.id,
        overlayType: 'infrastructure',
        overlayData: { roads_affected: 32, buildings_flooded: 187, bridges_damaged: 2 },
        imageUrl: overlayImageUrls.infrastructure,
        enabled: false
      },
      {
        id: `overlay-${image.id}-pop`,
        sarImageId: image.id,
        overlayType: 'population',
        overlayData: { affected: 45000, evacuated: 12000 },
        imageUrl: overlayImageUrls.population,
        enabled: false
      }
    );
  } else {
    baseOverlays.push(
      {
        id: `overlay-${image.id}-water`,
        sarImageId: image.id,
        overlayType: 'water_extent',
        overlayData: { area_km2: 22.1 + Math.random() * 3, features: 'receding flood waters' },
        imageUrl: overlayImageUrls.water_extent,
        enabled: true
      },
      {
        id: `overlay-${image.id}-change`,
        sarImageId: image.id,
        overlayType: 'change_detection',
        overlayData: { recovery: 46.4, remaining_water: 6.9, unit: 'km2' },
        imageUrl: overlayImageUrls.change_detection,
        enabled: false
      },
      {
        id: `overlay-${image.id}-infra`,
        sarImageId: image.id,
        overlayType: 'infrastructure',
        overlayData: { roads_recovered: 28, buildings_accessible: 201, repairs_needed: 34 },
        imageUrl: overlayImageUrls.infrastructure,
        enabled: false
      },
      {
        id: `overlay-${image.id}-terrain`,
        sarImageId: image.id,
        overlayType: 'terrain',
        overlayData: { risk_zones: ['low', 'medium', 'high'], vulnerable_areas: 12 },
        imageUrl: overlayImageUrls.terrain,
        enabled: false
      }
    );
  }

  return baseOverlays;
});

export const floodMetrics: FloodMetrics[] = studyAreas.flatMap(area => [
  {
    id: `metric-${area.id}-pre`,
    studyAreaId: area.id,
    phase: 'pre_flood' as FloodPhase,
    waterCoverageKm2: 15.2 + Math.random() * 5,
    affectedPopulation: 0,
    infrastructureDamage: { status: 'normal', risk_level: 'low' },
    analysisDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: `metric-${area.id}-during`,
    studyAreaId: area.id,
    phase: 'during_event' as FloodPhase,
    waterCoverageKm2: 68.5 + Math.random() * 10,
    affectedPopulation: 45000 + Math.floor(Math.random() * 10000),
    infrastructureDamage: {
      roads_affected: 32,
      buildings_damaged: 187,
      estimated_cost_usd: 12500000
    },
    analysisDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: `metric-${area.id}-post`,
    studyAreaId: area.id,
    phase: 'post_analysis' as FloodPhase,
    waterCoverageKm2: 22.1 + Math.random() * 3,
    affectedPopulation: 8500 + Math.floor(Math.random() * 2000),
    infrastructureDamage: {
      recovery_rate: 0.68,
      ongoing_repairs: 34,
      estimated_recovery_days: 45
    },
    analysisDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
  }
]);
