export type FloodPhase = 'pre_flood' | 'during_event' | 'post_analysis';

export type OverlayType = 'water_extent' | 'change_detection' | 'infrastructure' | 'population' | 'terrain';

export interface StudyArea {
  id: string;
  name: string;
  location: string;
  latitude: number;
  longitude: number;
  description: string;
}

export interface SARImage {
  id: string;
  studyAreaId: string;
  imageUrl: string;
  phase: FloodPhase;
  captureDate: string;
  satellite: string;
  metadata: Record<string, any>;
}

export interface ImageOverlay {
  id: string;
  sarImageId: string;
  overlayType: OverlayType;
  overlayData: Record<string, any>;
  imageUrl: string;
  enabled: boolean;
}

export interface FloodMetrics {
  id: string;
  studyAreaId: string;
  phase: FloodPhase;
  waterCoverageKm2: number;
  affectedPopulation: number;
  infrastructureDamage: Record<string, any>;
  analysisDate: string;
}
