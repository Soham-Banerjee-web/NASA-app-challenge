import { MapPin, Waves, Mountain, AlertTriangle } from 'lucide-react';
import { useState } from 'react';

interface MapPoint {
  id: number;
  x: number;
  y: number;
  label: string;
  description: string;
  type: 'lake' | 'dam' | 'affected' | 'epicenter';
  icon: React.ReactNode;
}

export function InteractiveMap() {
  const [selectedPoint, setSelectedPoint] = useState<number | null>(null);

  const mapPoints: MapPoint[] = [
    {
      id: 1,
      x: 30,
      y: 20,
      label: 'South Lhonak Lake',
      description: 'Glacial lake at 5,200m elevation. Primary source of the GLOF event.',
      type: 'lake',
      icon: <Waves className="w-4 h-4" />
    },
    {
      id: 2,
      x: 35,
      y: 35,
      label: 'Moraine Dam',
      description: 'Natural dam structure that failed, releasing approximately 15 million cubic meters of water.',
      type: 'dam',
      icon: <Mountain className="w-4 h-4" />
    },
    {
      id: 3,
      x: 45,
      y: 55,
      label: 'Chungthang',
      description: 'Major town severely affected. Teesta III Dam breached here.',
      type: 'affected',
      icon: <AlertTriangle className="w-4 h-4" />
    },
    {
      id: 4,
      x: 60,
      y: 70,
      label: 'Mangan',
      description: 'District headquarters impacted by flood waters. Infrastructure damage reported.',
      type: 'affected',
      icon: <MapPin className="w-4 h-4" />
    },
    {
      id: 5,
      x: 70,
      y: 85,
      label: 'Rangpo',
      description: 'Border town affected as flood waters continued downstream along Teesta River.',
      type: 'affected',
      icon: <MapPin className="w-4 h-4" />
    }
  ];

  const getPointColor = (type: string, isSelected: boolean) => {
    if (isSelected) {
      return 'bg-cyan-400 ring-4 ring-cyan-400/40 scale-125';
    }
    switch (type) {
      case 'lake':
        return 'bg-blue-500 hover:bg-blue-400';
      case 'dam':
        return 'bg-amber-500 hover:bg-amber-400';
      case 'affected':
        return 'bg-red-500 hover:bg-red-400';
      case 'epicenter':
        return 'bg-purple-500 hover:bg-purple-400';
      default:
        return 'bg-slate-500 hover:bg-slate-400';
    }
  };

  return (
    <div className="bg-slate-800/50 rounded-xl p-8 border border-slate-600">
      <div className="relative w-full h-96 bg-gradient-to-br from-slate-700 to-slate-800 rounded-lg overflow-hidden border border-slate-600">
        <div className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/9656049/pexels-photo-9656049.jpeg?auto=compress&cs=tinysrgb&w=1200)',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        ></div>

        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <defs>
            <linearGradient id="flowGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.2" />
            </linearGradient>
          </defs>
          {mapPoints.map((point, index) => {
            if (index < mapPoints.length - 1) {
              const nextPoint = mapPoints[index + 1];
              return (
                <path
                  key={`path-${point.id}`}
                  d={`M ${point.x}% ${point.y}% Q ${(point.x + nextPoint.x) / 2}% ${(point.y + nextPoint.y) / 2 - 5}% ${nextPoint.x}% ${nextPoint.y}%`}
                  stroke="url(#flowGradient)"
                  strokeWidth="3"
                  fill="none"
                  strokeDasharray="8 4"
                  className="animate-pulse"
                />
              );
            }
            return null;
          })}
        </svg>

        {mapPoints.map((point) => (
          <div
            key={point.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10"
            style={{ left: `${point.x}%`, top: `${point.y}%` }}
            onClick={() => setSelectedPoint(selectedPoint === point.id ? null : point.id)}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${getPointColor(point.type, selectedPoint === point.id)} shadow-lg`}>
              <span className="text-white">{point.icon}</span>
            </div>

            {selectedPoint === point.id && (
              <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 w-64 bg-slate-900 border border-cyan-500 rounded-lg p-4 shadow-2xl animate-fadeIn">
                <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-slate-900 border-l border-t border-cyan-500 rotate-45"></div>
                <h4 className="text-white font-bold mb-2">{point.label}</h4>
                <p className="text-slate-300 text-sm leading-relaxed">{point.description}</p>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
          <span className="text-slate-300 text-sm">Glacial Lake</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
          <span className="text-slate-300 text-sm">Dam Structure</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
          <span className="text-slate-300 text-sm">Affected Area</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-cyan-400 rounded-full"></div>
          <span className="text-slate-300 text-sm">Selected</span>
        </div>
      </div>
    </div>
  );
}
